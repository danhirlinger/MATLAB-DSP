function [out] = tiltEQ(input,tilt)
% Dan Hirlinger
% 3/3/21
Fs = 48000;
Nyq = Fs / 2;
N = length(input);
% tilt has raneg -6:6dB
% when tilt is negative, lows are boosted
% when tilt is positive, highs are boosted
% tilt dB amount is the max change in A between 0Hz - Nyquist
% between 0 and Nyquist, tilt has constant slope


% currently only works with 3 cases: -6, 0, and +6 dB
% run into error when changing below values of the extremes, as 
% the specified step size alters the number of items in the array

% I believe that I have approached the problem wrong with this method


% at highest difference, minimum A will be 0; max will be 1
if tilt > 0 % highs boosted, lows subdued
    A = [0 : 1/Nyq : 1];
elseif tilt < 0 % lows boosted, highs subdued
    A = [1 : -1/Nyq : 0];
else % flat Eq; no filtering effect
    A = [ones(1,Nyq+1)];
end
tilt = 10^(tilt/20);
order = 1; % m

F = [0 : 1/Nyq : 1];
% A = [0 : 1/Nyq : 1]; % +/-1 = +/- 6dB 
h = fir2(order,F,A);
freqz(h);

out = conv(x,h);
