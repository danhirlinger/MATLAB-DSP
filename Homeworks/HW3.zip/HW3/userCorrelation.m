% userCorrelation.m

% This is a script you should use for 
% Problem 2 in order to verify the performance
% of your solution. Make sure your code
% can automatically adjust to signals of different
% lengths. 

% Your code should create two array variables:
% r = correlation function
% l = lag values

% Example vectors from test
x = [2 ; -1 ; 1 ; -2 ; 4];
y = [1 ; 3 ; -2 ; -1 ; 1.5];

% Alternative input signals
%x = randn(10,1);
%y = randn(10,1);

% ADD YOUR CODE HERE:



% Make sure your result matches the built-in function
[R,L] = xcorr(x,y)

