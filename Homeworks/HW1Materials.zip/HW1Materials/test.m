% test
% Run this to visualize the DI signal compared to distorted

[in,Fs1] = audioread('BassDI.wav');
[ref,Fs2] = audioread('LA3APrint.wav');


plot(in); % Un-distored
hold on;
plot(ref);      % Distorted
hold off;