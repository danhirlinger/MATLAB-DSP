function [ b,a ] = biQuadCalc( F,Q,dB,Fs,type )
% biQuadCalc.m
% Calculates filter coeffecients for a biquad filter
% All formulas taken from the Audio EQ Cookbook

Ts = 1/Fs;
w0 = 2*pi*F*Ts;

    % LPF
if type == 1 
    alpha = sin(w0)/(2*Q);

    b(1) = (1 - cos(w0))/2;
    b(2) =   1 - cos(w0);
    b(3) =  (1 - cos(w0))/2;
    a(1) =   1 + alpha;
    a(2) =  -2*cos(w0);
    a(3) =   1 - alpha;
    
    % HPF
elseif type == 2
     alpha = sin(w0)/(2*Q);
    
    b(1) =  (1 + cos(w0))/2;
    b(2) = -(1 + cos(w0));
    b(3) =  (1 + cos(w0))/2;
    a(1) =   1 + alpha;
    a(2) =  -2*cos(w0);
	a(3) =   1 - alpha;

    % Bell Curve
elseif type == 3
    alpha = sin(w0)/(2*Q);
    A = sqrt(10^(dB/20));
    
    b(1) =   1 + alpha*A;
	b(2) =  -2*cos(w0);
	b(3) =   1 - alpha*A;
	a(1) =   1 + alpha/A;
	a(2) =  -2*cos(w0);
	a(3) =   1 - alpha/A;
    
    % High Shelf    
elseif type == 4
    
    A = sqrt(10^(dB/20));
    alpha = sin(w0)/2 * sqrt( (A + 1/A)*(1/Q - 1) + 2);
    
    b(1) = A*( (A+1) + (A-1)*cos(w0) + 2*sqrt(A)*alpha);
	b(2) = -2*A*((A-1) + (A+1)*cos(w0));
	b(3) = A*((A+1) + (A-1)*cos(w0) - 2*sqrt(A)*alpha);
	a(1) = (A+1) - (A-1)*cos(w0) + 2*sqrt(A)*alpha;
	a(2) = 2*( (A-1) - (A+1)*cos(w0));
	a(3) = (A+1) - (A-1)*cos(w0) - 2*sqrt(A)*alpha;
    
    % Low Shelf
elseif type == 5
    
    A = sqrt(10^(dB/20));
    alpha = sin(w0)/2 * sqrt( (A + 1/A)*(1/Q - 1) + 2);
    
    b(1) = A*((A+1) - (A-1)*cos(w0) + 2*sqrt(A)*alpha);
    b(2) = 2*A*((A-1) - (A+1)*cos(w0));
	b(3) = A*((A+1) - (A-1)*cos(w0) - 2*sqrt(A)*alpha);
	a(1) = (A+1) + (A-1)*cos(w0) + 2*sqrt(A)*alpha;
	a(2) = -2*( (A-1) + (A+1)*cos(w0));
	a(3) = (A+1) + (A-1)*cos(w0) - 2*sqrt(A)*alpha;
    
    %All-pass
elseif type == 6
    alpha = sin(w0)/(2*Q);
    
    b(1) = 1 - alpha;
	b(2) = -2*cos(w0);
	b(3) = 1 + alpha;
	a(1) = 1 + alpha;
	a(2) = -2*cos(w0);
	a(3) = 1 - alpha;
    
    % Notch
elseif type == 7
    
    alpha = sin(w0)*sinh(log(2)/2 * (1/Q) * w0/sin(w0));
    
    b(1) = 1;
	b(2) = -2*cos(w0);
	b(3) = 1;
	a(1) = 1 + alpha;
	a(2) = -2*cos(w0);
	a(3) = 1 - alpha;
    
    % Band-pass
elseif type == 8
    
    alpha = sin(w0)*sinh(log(2)/2 * (1/Q) * w0/sin(w0));
    
    b(1) = alpha;
	b(2) = 0;
	b(3) = -alpha;
	a(1) = 1 + alpha;
	a(2) = -2*cos(w0);
	a(3) = 1 - alpha;
end    
end

