function varargout = poleZeroEQ(varargin)
% POLEZEROEQ MATLAB code for poleZeroEQ.fig
%     
%
% See also: GUIDE, GUIDATA, GUIHANDLES

% Edit the above text to modify the response to help poleZeroEQ

% Last Modified by GUIDE v2.5 26-Apr-2017 22:20:14

% Begin initialization code - DO NOT EDIT
gui_Singleton = 1;
gui_State = struct('gui_Name',       mfilename, ...
                   'gui_Singleton',  gui_Singleton, ...
                   'gui_OpeningFcn', @poleZeroEQ_OpeningFcn, ...
                   'gui_OutputFcn',  @poleZeroEQ_OutputFcn, ...
                   'gui_LayoutFcn',  [] , ...
                   'gui_Callback',   []);
if nargin && ischar(varargin{1})
    gui_State.gui_Callback = str2func(varargin{1});
end

if nargout
    [varargout{1:nargout}] = gui_mainfcn(gui_State, varargin{:});
else
    gui_mainfcn(gui_State, varargin{:});
end
% End initialization code - DO NOT EDIT


% --- Executes just before poleZeroEQ is made visible.
function poleZeroEQ_OpeningFcn(hObject, eventdata, handles, varargin)
% This function has no output args, see OutputFcn.
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
% varargin   command line arguments to poleZeroEQ (see VARARGIN)

% Sets default positions and parameters

global Fs
global F
global Q
global dB
global type
global b
global a

Fs = 48000;
F = get(handles.freqSlider, 'Value');

set(handles.freqText, 'String', num2str(F))
set(handles.qValueText, 'String', '0.707')
set(handles.dBSlider,'value', 0)
set(handles.dBSlider,'visible','off')
set(handles.dBText,'visible','off')
set(handles.dBText,'String', '0')    
set(handles.plus18,'visible','off')
set(handles.minus18,'visible','off')
set(handles.gainLabel,'visible','off')
set(handles.playUnprocessed,'enable','off')
set(handles.playProcessed,'enable','off')

dB = 0;
Q = 0.707;
type = 1;

[b,a] = biQuadCalc(F,Q,dB,Fs,type);

axes(handles.poleZero)
zplane(b,a)

[h,w] = freqz(b,a,Fs,Fs);

axes(handles.freqz)
semilogx(w,20*log10(abs(h)))
axis([20 20000 -18 18])   
set(gca, 'XTick', [20 100 1000 10000 20000])
set(gca, 'XTickLabel', {'20Hz', '100Hz', '1kHz', '10kHz', '20kHz'}.');
xlabel('Frequency (Hz)')
ylabel('Gain (dB)')

% Choose default command line output for poleZeroEQ
handles.output = hObject;

% Update handles structure
guidata(hObject, handles);


% --- Outputs from this function are returned to the command line.
function varargout = poleZeroEQ_OutputFcn(hObject, eventdata, handles) 
% varargout  cell array for returning output args (see VARARGOUT);
% hObject    handle to figure
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

% Get default command line output from handles structure
varargout{1} = handles.output;


% --- Executes on slider movement.
function freqSlider_Callback(hObject, eventdata, handles)
% hObject    handle to freqSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global Fs
global F
global Q
global dB
global type
global b
global a

% Updates filter based on freqSlider value
F = get(handles.freqSlider, 'Value');
set(handles.freqText, 'String', num2str(F))
[b,a] = biQuadCalc(F,Q,dB,Fs,type);

axes(handles.poleZero)
zplane(b,a)

[h,w] = freqz(b,a,Fs,Fs);

axes(handles.freqz)
semilogx(w,20*log10(abs(h)))
axis([20 20000 -18 18])   
set(gca, 'XTick', [20 100 1000 10000 20000])
set(gca, 'XTickLabel', {'20Hz', '100Hz', '1kHz', '10kHz', '20kHz'}.');
xlabel('Frequency (Hz)')
ylabel('Gain (dB)')


% --- Executes during object creation, after setting all properties.
function freqSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to freqSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end


function qValueText_Callback(hObject, eventdata, handles)
% hObject    handle to qValueText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global Fs
global F
global Q
global dB
global type
global b
global a

% Updates filter based on Q value
Q = str2double(get(handles.qValueText, 'String'));

[b,a] = biQuadCalc(F,Q,dB,Fs,type);

axes(handles.poleZero)
zplane(b,a)

[h,w] = freqz(b,a,Fs,Fs);

axes(handles.freqz)
semilogx(w,20*log10(abs(h)))
axis([20 20000 -18 18])   
set(gca, 'XTick', [20 100 1000 10000 20000])
set(gca, 'XTickLabel', {'20Hz', '100Hz', '1kHz', '10kHz', '20kHz'}.');
xlabel('Frequency (Hz)')
ylabel('Gain (dB)')


% --- Executes during object creation, after setting all properties.
function qValueText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to qValueText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


function freqText_Callback(hObject, eventdata, handles)
% hObject    handle to freqText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global F
global Fs
global Q
global dB
global type
global b
global a

% Updates filter based on freqText
F = str2num(get(handles.freqText, 'String'));

[b,a] = biQuadCalc(F,Q,dB,Fs,type);

axes(handles.poleZero)
zplane(b,a)

[h,w] = freqz(b,a,Fs,Fs);

axes(handles.freqz)
semilogx(w,20*log10(abs(h)))
axis([20 20000 -18 18])   
set(gca, 'XTick', [20 100 1000 10000 20000])
set(gca, 'XTickLabel', {'20Hz', '100Hz', '1kHz', '10kHz', '20kHz'}.');
xlabel('Frequency (Hz)')
ylabel('Gain (dB)')


% --- Executes during object creation, after setting all properties.
function freqText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to freqText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on selection change in filterType.
function filterType_Callback(hObject, eventdata, handles)
% hObject    handle to filterType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global F
global Fs
global Q
global dB
global type
global b
global a

% Retrieves filter type from drop down menu
type = get(handles.filterType,'Value');

% Enables gain parameters for bell and shelving filters
if type == 3 || type == 4 || type == 5
    set(handles.dBSlider,'visible','on')
    set(handles.dBText,'visible','on')
    set(handles.plus18,'visible','on')
    set(handles.minus18,'visible','on')
    set(handles.gainLabel,'visible','on')

else
    set(handles.dBSlider,'visible','off')
    set(handles.dBText,'visible','off')
    set(handles.plus18,'visible','off')
    set(handles.minus18,'visible','off')
    set(handles.gainLabel,'visible','off')
    
end

[b,a] = biQuadCalc(F,Q,dB,Fs,type);

axes(handles.poleZero)
zplane(b,a)

[h,w] = freqz(b,a,Fs,Fs);

axes(handles.freqz)
semilogx(w,20*log10(abs(h)))
axis([20 20000 -18 18])   
set(gca, 'XTick', [20 100 1000 10000 20000])
set(gca, 'XTickLabel', {'20Hz', '100Hz', '1kHz', '10kHz', '20kHz'}.');
xlabel('Frequency (Hz)')
ylabel('Gain (dB)')


% --- Executes during object creation, after setting all properties.
function filterType_CreateFcn(hObject, eventdata, handles)
% hObject    handle to filterType (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: popupmenu controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on slider movement.
function dBSlider_Callback(hObject, eventdata, handles)
% hObject    handle to dBSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global F
global Fs
global Q
global dB
global type
global b
global a

% Updates filter based on gainSlider value
dB = get(handles.dBSlider,'Value');
set(handles.dBText,'String',[num2str(dB)])

[b,a] = biQuadCalc(F,Q,dB,Fs,type);

axes(handles.poleZero)
zplane(b,a)

[h,w] = freqz(b,a,Fs,Fs);

axes(handles.freqz)
semilogx(w,20*log10(abs(h)))
axis([20 20000 -18 18])   
set(gca, 'XTick', [20 100 1000 10000 20000])
set(gca, 'XTickLabel', {'20Hz', '100Hz', '1kHz', '10kHz', '20kHz'}.');
xlabel('Frequency (Hz)')
ylabel('Gain (dB)')


% --- Executes during object creation, after setting all properties.
function dBSlider_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dBSlider (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: slider controls usually have a light gray background.
if isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor',[.9 .9 .9]);
end



function dBText_Callback(hObject, eventdata, handles)
% hObject    handle to dBText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global F
global Fs
global Q
global dB
global type
global b
global a

% Gets text from dBText box, updates gain slider with current value
dB = str2double(get(handles.dBText,'String'));
set(handles.dBText,'String',num2str(dB))

[b,a] = biQuadCalc(F,Q,dB,Fs,type);

axes(handles.poleZero)
zplane(b,a)

[h,w] = freqz(b,a,Fs,Fs);

axes(handles.freqz)
semilogx(w,20*log10(abs(h)))
axis([20 20000 -18 18])   
set(gca, 'XTick', [20 100 1000 10000 20000])
set(gca, 'XTickLabel', {'20Hz', '100Hz', '1kHz', '10kHz', '20kHz'}.');
xlabel('Frequency (Hz)')
ylabel('Gain (dB)')


% --- Executes during object creation, after setting all properties.
function dBText_CreateFcn(hObject, eventdata, handles)
% hObject    handle to dBText (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    empty - handles not created until after all CreateFcns called

% Hint: edit controls usually have a white background on Windows.
%       See ISPC and COMPUTER.
if ispc && isequal(get(hObject,'BackgroundColor'), get(0,'defaultUicontrolBackgroundColor'))
    set(hObject,'BackgroundColor','white');
end


% --- Executes on button press in importButton.
function importButton_Callback(hObject, eventdata, handles)
% hObject    handle to importButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global x
global Fs

% Opens file selection menu
[filename,pathname] = uigetfile('*.wav');

% Provides fix if user cancels upload
if filename ~=0   
    [x,Fs] = audioread([pathname filename]);
    set(handles.playUnprocessed,'enable','on')
    set(handles.playProcessed,'enable','on')
    
end


% --- Executes on button press in playUnprocessed.
function playUnprocessed_Callback(hObject, eventdata, handles)
% hObject    handle to playUnprocessed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
clear sound
global x
global Fs

% Play unprocessed audio file
sound(x,Fs)


% --- Executes on button press in playProcessed.
function playProcessed_Callback(hObject, eventdata, handles)
% hObject    handle to playProcessed (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

clear sound
global x
global Fs
global b
global a

% Filter imported audio file with the current filter settings
y = filter(b,a,x);
sound(y,Fs)


% --- Executes on button press in impulseButton.
function impulseButton_Callback(hObject, eventdata, handles)
% hObject    handle to impulseButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)
global b
global a

% Plot impulse response of current filter
[ir,t] = impz(b,a);

figure
stem(t,ir)
xlabel('Time (Samples)')
title('Filter Impulse Response')
set(gcf,'numbertitle','off','name','Filter Impulse Response')


% --- Executes on button press in phaseButton.
function phaseButton_Callback(hObject, eventdata, handles)
% hObject    handle to phaseButton (see GCBO)
% eventdata  reserved - to be defined in a future version of MATLAB
% handles    structure with handles and user data (see GUIDATA)

global b
global a
global Fs

% Plot phase response based on current filter parameters
[phi,f] = phasez(b,a,Fs,Fs);

figure
semilogx(f,phi*(180/pi))
ylim auto
xlim([20 20000])
set(gca, 'XTick', [20 100 1000 10000 20000])
set(gca, 'XTickLabel', {'20Hz', '100Hz', '1kHz', '10kHz', '20kHz'}.');
xlabel('Frequency (Hz)')
ylabel('Phase (Degrees)')
title('Filter Phase Response')
set(gcf,'numbertitle','off','name','Filter Phase Response')

